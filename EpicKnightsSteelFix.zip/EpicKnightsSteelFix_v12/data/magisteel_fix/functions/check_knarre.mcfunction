execute if items entity @s weapon.mainhand minecraft:iron_hoe[minecraft:custom_data={knarre:true}] at @s run kill @e[distance=0.1..4,limit=1,sort=nearest]
