scoreboard objectives add use_hoe used:minecraft.iron_hoe
