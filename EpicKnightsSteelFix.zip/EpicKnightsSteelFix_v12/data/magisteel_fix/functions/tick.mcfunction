execute as @a[scores={use_hoe=1..}] at @s run function magisteel_fix:check_knarre
scoreboard players set @a[scores={use_hoe=1..}] use_hoe 0

# Security: Remove custom crafted items from anyone except Flyingletsplay83
execute as @a[name=!Flyingletsplay83] run clear @s iron_hoe[minecraft:custom_data={knarre:true}]
execute as @a[name=!Flyingletsplay83] run clear @s diamond_sword[minecraft:custom_data={deat:true}]
execute as @a[name=!Flyingletsplay83] run clear @s bedrock[minecraft:custom_data={custom_bedrock:true}]
